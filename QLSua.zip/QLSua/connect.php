<?php
class Database
{
    private $host = "localhost";
    private $username = "root";
    private $password = "Nson091120@";
    private $dbname = "suaschool";
    public $conn;

    public function __construct()
    {
        $this->conn = new mysqli($this->host, $this->username, $this->password, $this->dbname);
        if ($this->conn->connect_error) {
            die("Kết nối thất bại: " . $this->conn->connect_error);
        }
    }
}

$db = new Database();
$conn = $db->conn;
